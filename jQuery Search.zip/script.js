/**
    * Author: Elijah H. Mullin
    * Date: April 18, 2022
    * Purpose: To create a basic search engine that functions through the use of jQuery commands as a                       * form of practice to strengthen my jQuery skills and understanding.
 **/

let search = document.getElementById("search");
let clear = document.getElementById("clear");

let r = 255;
let g = 0;
let b = 0;

function countrySelect(){
    if($("#country").val() === "ca"){
       $("#flag").attr("src", "images/ca.jpg");
       }
    
    else if($("#country").val() === "us"){
            $("#flag").attr("src", "images/us.png");
            }
    
    else{
        $("#flag").attr("src", "images/uk.png");
    }
}

function setLink(){
    if($("#bar").val() != ""){
       if($("#country").val() === "ca"){
          $("#err").html("");
          let newLink = "https://www." + $("#bar").val() + ".ca";
          $("#link").attr("href", newLink);
          }
       
       else if($("#country").val() === "us"){
               $("#err").html("");
               let newLink = "https://www." + $("#bar").val() + ".com";
               $("#link").attr("href", newLink);
               }
       
       else{
            $("#err").html("");
            let newLink = "https://www." + $("#bar").val() + ".uk";
            $("#link").attr("href", newLink);
       }
    }
}

function clearSearchbar(){
    if ($("#bar").val() === ""){
        $("#err").html("There is nothing to clear.");
        } else {
            $("#err").html("");
            $("#bar").val("");
    }
}

function rgb(){
    if (r > 0 && g < 255 && b == 0){
        r -= 1;
        g += 1;
    }
    
    else if(g > 0 && b < 255 && r == 0){
        g -= 1;
        b += 1;
    }
    
    else if(b > 0 && g == 0){
        r += 1;
        b -= 1;
    }
    
    $(".btn").css({
        backgroundColor: "rgb(" + r + ", " + g + ", " + b + ")"
    });
    
    $("#bar").css({
        borderColor: "rgb(" + r + ", " + g + ", " + b + ")"
    });
}

function animate(){
    setInterval(rgb, 10);
}


window.addEventListener("load", animate);
window.addEventListener("load", countrySelect);
search.addEventListener("click", setLink);
clear.addEventListener("click", clearSearchbar);