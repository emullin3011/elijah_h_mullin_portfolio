function check() {
    if (document.getElementById("capsCheck").checked == true || document.getElementById("shiftCheck").checked == true) {
        document.getElementById("a").innerHTML = "A";
        document.getElementById("b").innerHTML = "B";
        document.getElementById("c").innerHTML = "C";
        document.getElementById("d").innerHTML = "D";
        document.getElementById("e").innerHTML = "E";
        document.getElementById("f").innerHTML = "F";
        document.getElementById("g").innerHTML = "G";
        document.getElementById("h").innerHTML = "H";
        document.getElementById("i").innerHTML = "I";
        document.getElementById("j").innerHTML = "J";
        document.getElementById("k").innerHTML = "K";
        document.getElementById("l").innerHTML = "L";
        document.getElementById("m").innerHTML = "M";
        document.getElementById("n").innerHTML = "N";
        document.getElementById("o").innerHTML = "O";
        document.getElementById("p").innerHTML = "P";
        document.getElementById("q").innerHTML = "Q";
        document.getElementById("r").innerHTML = "R";
        document.getElementById("s").innerHTML = "S";
        document.getElementById("t").innerHTML = "T";
        document.getElementById("u").innerHTML = "U";
        document.getElementById("v").innerHTML = "V";
        document.getElementById("w").innerHTML = "W";
        document.getElementById("x").innerHTML = "X";
        document.getElementById("y").innerHTML = "Y";
        document.getElementById("z").innerHTML = "Z";
    } else {
        document.getElementById("a").innerHTML = "a";
        document.getElementById("b").innerHTML = "b";
        document.getElementById("c").innerHTML = "c";
        document.getElementById("d").innerHTML = "d";
        document.getElementById("e").innerHTML = "e";
        document.getElementById("f").innerHTML = "f";
        document.getElementById("g").innerHTML = "g";
        document.getElementById("h").innerHTML = "h";
        document.getElementById("i").innerHTML = "i";
        document.getElementById("j").innerHTML = "j";
        document.getElementById("k").innerHTML = "k";
        document.getElementById("l").innerHTML = "l";
        document.getElementById("m").innerHTML = "m";
        document.getElementById("n").innerHTML = "n";
        document.getElementById("o").innerHTML = "o";
        document.getElementById("p").innerHTML = "p";
        document.getElementById("q").innerHTML = "q";
        document.getElementById("r").innerHTML = "r";
        document.getElementById("s").innerHTML = "s";
        document.getElementById("t").innerHTML = "t";
        document.getElementById("u").innerHTML = "u";
        document.getElementById("v").innerHTML = "v";
        document.getElementById("w").innerHTML = "w";
        document.getElementById("x").innerHTML = "x";
        document.getElementById("y").innerHTML = "y";
        document.getElementById("z").innerHTML = "z";
    }
}

function tab() {
    document.getElementById("textbox").innerHTML += "\t";
}

function caps() {
    if (document.getElementById("capsCheck").checked == false) {
        document.getElementById("capsCheck").checked = true;

        document.getElementById("caps").style.backgroundColor = "lime";
        document.getElementById("caps").style.color = "white";
        check();
    } else {
        document.getElementById("capsCheck").checked = false;

        document.getElementById("caps").style.backgroundColor = "black";
        document.getElementById("caps").style.color = "lime";
        check();
    }
}

function shift1() {
    if (document.getElementById("shiftCheck").checked == false) {
        document.getElementById("shiftCheck").checked = true;

        document.getElementById("shift1").style.backgroundColor = "lime";
        document.getElementById("shift1").style.color = "white";
        check();
    } else {
        document.getElementById("shiftCheck").checked = false;

        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        check();
    }
}

function shift2() {
    if (document.getElementById("shiftCheck").checked == false) {
        document.getElementById("shiftCheck").checked = true;

        document.getElementById("shift2").style.backgroundColor = "lime";
        document.getElementById("shift2").style.color = "white";
        check();
    } else {
        document.getElementById("shiftCheck").checked = false;

        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift2").style.color = "lime";
        check();
    }
}

function bksp() {
    let newText = "";
    for (i = 0; i < document.getElementById("textbox").innerHTML.length - 1; i++) {
        newText += document.getElementById("textbox").innerHTML[i];
    }

    document.getElementById("textbox").innerHTML = newText;
}

function enter() {
    document.getElementById("textbox").innerHTML += "\n";
}

function a() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "A";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "a";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "A";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "a";
    }
}

function b() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "B";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "b";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "B";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "b";
    }
}

function c() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "C";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "c";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "C";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "c";
    }
}

function d() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "D";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "d";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "D";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "d";
    }
}

function e() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "E";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "e";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "E";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "e";
    }
}

function f() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "F";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "f";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "F";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "f";
    }
}

function g() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "G";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "g";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "G";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "g";
    }
}

function h() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "H";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "h";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "H";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "h";
    }
}

function i() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "I";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "i";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "I";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "i";
    }
}

function j() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "J";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "j";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "J";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "j";
    }
}

function k() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "K";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "k";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "K";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "k";
    }
}

function l() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "L";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "l";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "L";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "l";
    }
}

function m() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "M";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "m";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "M";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "m";
    }
}

function n() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "N";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "n";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "N";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "n";
    }
}

function o() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "O";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "o";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "O";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "o";
    }
}

function p() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "P";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "p";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "P";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "p";
    }
}

function q() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "Q";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "q";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "Q";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "q";
    }
}

function r() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "R";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "r";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "R";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "r";
    }
}

function s() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "S";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "s";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "S";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "s";
    }
}

function t() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "T";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "t";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "T";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "t";
    }
}

function u() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "U";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "u";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "U";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "u";
    }
}

function v() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "V";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "v";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "V";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "v";
    }
}

function w() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "W";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "w";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "W";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "w";
    }
}

function x() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "X";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "x";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "X";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "x";
    }
}

function y() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "Y";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "y";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "Y";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "y";
    }
}

function z() {
    if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == false) {
        document.getElementById("textbox").innerHTML += "Z";
    } else if (document.getElementById("capsCheck").checked == true && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "z";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
    } else if (document.getElementById("capsCheck").checked == false && document.getElementById("shiftCheck").checked == true) {
        document.getElementById("textbox").innerHTML += "Z";

        document.getElementById("shiftCheck").checked = false;
        document.getElementById("shift1").style.backgroundColor = "black";
        document.getElementById("shift2").style.backgroundColor = "black";
        document.getElementById("shift1").style.color = "lime";
        document.getElementById("shift2").style.color = "lime";
        check();
    } else {
        document.getElementById("textbox").innerHTML += "z";
    }
}

function key0() {
    document.getElementById("textbox").innerHTML += "0";
}

function key1() {
    document.getElementById("textbox").innerHTML += "1";
}

function key2() {
    document.getElementById("textbox").innerHTML += "2";
}

function key3() {
    document.getElementById("textbox").innerHTML += "3";
}

function key4() {
    document.getElementById("textbox").innerHTML += "4";
}

function key5() {
    document.getElementById("textbox").innerHTML += "5";
}

function key6() {
    document.getElementById("textbox").innerHTML += "6";
}

function key7() {
    document.getElementById("textbox").innerHTML += "7";
}

function key8() {
    document.getElementById("textbox").innerHTML += "8";
}

function key9() {
    document.getElementById("textbox").innerHTML += "9";
}

function space() {
    document.getElementById("textbox").innerHTML += " ";
}

function sym1(){
    document.getElementById("textbox").innerHTML += "!";
}

function sym2() {
    document.getElementById("textbox").innerHTML += "@";
}

function sym3() {
    document.getElementById("textbox").innerHTML += "#";
}

function sym4() {
    document.getElementById("textbox").innerHTML += "$";
}

function sym5() {
    document.getElementById("textbox").innerHTML += "%";
}

function sym6() {
    document.getElementById("textbox").innerHTML += "^";
}

function sym7() {
    document.getElementById("textbox").innerHTML += "*";
}

function sym8() {
    document.getElementById("textbox").innerHTML += "(";
}

function sym9() {
    document.getElementById("textbox").innerHTML += ")";
}

function sym10() {
    document.getElementById("textbox").innerHTML += "-";
}

function sym11() {
    document.getElementById("textbox").innerHTML += "_";
}

function sym12() {
    document.getElementById("textbox").innerHTML += "=";
}

function sym13() {
    document.getElementById("textbox").innerHTML += "+";
}

function sym14() {
    document.getElementById("textbox").innerHTML += "[";
}

function sym15() {
    document.getElementById("textbox").innerHTML += "{";
}

function sym16() {
    document.getElementById("textbox").innerHTML += "]";
}

function sym17() {
    document.getElementById("textbox").innerHTML += "}";
}

function sym18() {
    document.getElementById("textbox").innerHTML += "|";
}

function sym19() {
    document.getElementById("textbox").innerHTML += ";";
}

function sym20() {
    document.getElementById("textbox").innerHTML += ":";
}

function sym21() {
    document.getElementById("textbox").innerHTML += "'";
}

function sym22() {
    document.getElementById("textbox").innerHTML += '"';
}

function sym23() {
    document.getElementById("textbox").innerHTML += ",";
}

function sym24() {
    document.getElementById("textbox").innerHTML += ".";
}

function sym25() {
    document.getElementById("textbox").innerHTML += "/";
}

function sym26() {
    document.getElementById("textbox").innerHTML += "?";
}

document.getElementById("tab").addEventListener("click", tab);
document.getElementById("caps").addEventListener("click", caps);
document.getElementById("shift1").addEventListener("click", shift1);
document.getElementById("bksp").addEventListener("click", bksp);
document.getElementById("ent").addEventListener("click", enter);
document.getElementById("shift2").addEventListener("click", shift2);
document.getElementById("space").addEventListener("click", space);

document.getElementById("a").addEventListener("click", a);
document.getElementById("b").addEventListener("click", b);
document.getElementById("c").addEventListener("click", c);
document.getElementById("d").addEventListener("click", d);
document.getElementById("e").addEventListener("click", e);
document.getElementById("f").addEventListener("click", f);
document.getElementById("g").addEventListener("click", g);
document.getElementById("h").addEventListener("click", h);
document.getElementById("i").addEventListener("click", i);
document.getElementById("j").addEventListener("click", j);
document.getElementById("k").addEventListener("click", k);
document.getElementById("l").addEventListener("click", l);
document.getElementById("m").addEventListener("click", m);
document.getElementById("n").addEventListener("click", n);
document.getElementById("o").addEventListener("click", o);
document.getElementById("p").addEventListener("click", p);
document.getElementById("q").addEventListener("click", q);
document.getElementById("r").addEventListener("click", r);
document.getElementById("s").addEventListener("click", s);
document.getElementById("t").addEventListener("click", t);
document.getElementById("u").addEventListener("click", u);
document.getElementById("v").addEventListener("click", v);
document.getElementById("w").addEventListener("click", w);
document.getElementById("x").addEventListener("click", x);
document.getElementById("y").addEventListener("click", y);
document.getElementById("z").addEventListener("click", z);

document.getElementById("0").addEventListener("click", key0);
document.getElementById("1").addEventListener("click", key1);
document.getElementById("2").addEventListener("click", key2);
document.getElementById("3").addEventListener("click", key3);
document.getElementById("4").addEventListener("click", key4);
document.getElementById("5").addEventListener("click", key5);
document.getElementById("6").addEventListener("click", key6);
document.getElementById("7").addEventListener("click", key7);
document.getElementById("8").addEventListener("click", key8);
document.getElementById("9").addEventListener("click", key9);

document.getElementById("!").addEventListener("click", sym1);
document.getElementById("@").addEventListener("click", sym2);
document.getElementById("#").addEventListener("click", sym3);
document.getElementById("$").addEventListener("click", sym4);
document.getElementById("%").addEventListener("click", sym5);
document.getElementById("^").addEventListener("click", sym6);
document.getElementById("*").addEventListener("click", sym7);
document.getElementById("(").addEventListener("click", sym8);
document.getElementById(")").addEventListener("click", sym9);
document.getElementById("-").addEventListener("click", sym10);
document.getElementById("_").addEventListener("click", sym11);
document.getElementById("=").addEventListener("click", sym12);
document.getElementById("+").addEventListener("click", sym13);
document.getElementById("[").addEventListener("click", sym14);
document.getElementById("{").addEventListener("click", sym15);
document.getElementById("]").addEventListener("click", sym16);
document.getElementById("}").addEventListener("click", sym17);
document.getElementById("|").addEventListener("click", sym18);
document.getElementById(";").addEventListener("click", sym19);
document.getElementById(":").addEventListener("click", sym20);
document.getElementById("'").addEventListener("click", sym21);
document.getElementById("dub").addEventListener("click", sym22);
document.getElementById(",").addEventListener("click", sym23);
document.getElementById(".").addEventListener("click", sym24);
document.getElementById("/").addEventListener("click", sym25);
document.getElementById("?").addEventListener("click", sym26);