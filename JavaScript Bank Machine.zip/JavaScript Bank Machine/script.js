let balance = 0;

function setBalance() {
    balance = Math.round(Math.random() * 1000);
    document.getElementById("random").innerHTML = balance; 
}

function add5() {
    let curr = parseInt(document.getElementById("5").value);
    curr++;
    document.getElementById("5").value = curr;
}

function add10() {
    let curr = parseInt(document.getElementById("10").value);
    curr++;
    document.getElementById("10").value = curr;
}

function add20() {
    let curr = parseInt(document.getElementById("20").value);
    curr++;
    document.getElementById("20").value = curr;
}

function add50() {
    let curr = parseInt(document.getElementById("50").value);
    curr++;
    document.getElementById("50").value = curr;
}

function add100() {
    let curr = parseInt(document.getElementById("100").value);
    curr++;
    document.getElementById("100").value = curr;
}

function sub5() {
    let curr = parseInt(document.getElementById("5").value);

    if (curr == 0) {
        alert("No negative requests are acceptable.");
    } else if (curr > 0) {
        curr--;
        document.getElementById("5").value = curr;
    }
}

function sub10() {
    let curr = parseInt(document.getElementById("10").value);

    if (curr == 0) {
        alert("No negative requests are acceptable.");
    } else if (curr > 0) {
        curr--;
        document.getElementById("10").value = curr;
    }
}

function sub20() {
    let curr = parseInt(document.getElementById("20").value);

    if (curr == 0) {
        alert("No negative requests are acceptable.");
    } else if (curr > 0) {
        curr--;
        document.getElementById("20").value = curr;
    }
}

function sub50() {
    let curr = parseInt(document.getElementById("50").value);

    if (curr == 0) {
        alert("No negative requests are acceptable.");
    } else if (curr > 0) {
        curr--;
        document.getElementById("50").value = curr;
    }
}

function sub100() {
    let curr = parseInt(document.getElementById("100").value);

    if (curr == 0) {
        alert("No negative requests are acceptable.");
    } else if (curr > 0) {
        curr--;
        document.getElementById("100").value = curr;
    }
}

function withdraw() {
    let entry = parseInt(document.getElementById("wd").value);

    let bill5 = 5 * parseInt(document.getElementById("5").value);
    let bill10 = 10 * parseInt(document.getElementById("10").value);
    let bill20 = 20 * parseInt(document.getElementById("20").value);
    let bill50 = 50 * parseInt(document.getElementById("50").value);
    let bill100 = 100 * parseInt(document.getElementById("100").value);
    let sum = bill5 + bill10 + bill20 + bill50 + bill100;

    if (document.getElementById("wd").value != "" && entry > 0) {
        if (entry % 5 == 0) {
            if (sum == entry && entry <= balance) {
                let amnt5 = document.getElementById("5").value;
                let amnt10 = document.getElementById("10").value;
                let amnt20 = document.getElementById("20").value;
                let amnt50 = document.getElementById("50").value;
                let amnt100 = document.getElementById("100").value;

                let timestamp = new Date();

                let diff = balance - entry;
                balance = diff;
                document.getElementById("random").innerHTML = diff;

                alert("Withdrawal Successful\n\nDate & Time of Withdrawal: " + timestamp + "\n\nAccount Balance Before Withdrawal: $" + (diff + entry) + "\nTotal Amount Withdrawn: $" + entry + "\nCurrent Account Balance: $" + diff + "\n5 Dollar Bills: " + amnt5 + "\n10 Dollar Bills: " + amnt10 + "\n20 Dollar Bills: " + amnt20 + "\n50 Dollar Bills: " + amnt50 + "\n100 Dollar Bills: " + amnt100);

                document.getElementById("wd").value = "";
                document.getElementById("5").value = "0";
                document.getElementById("10").value = "0";
                document.getElementById("20").value = "0";
                document.getElementById("50").value = "0";
                document.getElementById("100").value = "0";
            } else if (sum != entry) {
                alert("Invalid request\nWithdrawal Amount Entered: " + entry + "\nAmount Requested in Dollar Bills: $" + sum);
            } else if (entry > balance) {
                alert("Insufficient funds. Please enter an amount less or equal to $" + balance + ".");
            }
        } else {
            alert("Please only request withdrawal amounts evenly divisible by 5 in order to complete the withdrawal process.");
        }
    } else {
        alert("Please enter a withdrawal amount greater than $0.00 in order to complete the withdrawal process.");
    }
}

window.addEventListener("load", setBalance);

document.getElementById("add5").addEventListener("click", add5);
document.getElementById("add10").addEventListener("click", add10);
document.getElementById("add20").addEventListener("click", add20);
document.getElementById("add50").addEventListener("click", add50);
document.getElementById("add100").addEventListener("click", add100);

document.getElementById("sub5").addEventListener("click", sub5);
document.getElementById("sub10").addEventListener("click", sub10);
document.getElementById("sub20").addEventListener("click", sub20);
document.getElementById("sub50").addEventListener("click", sub50);
document.getElementById("sub100").addEventListener("click", sub100);

document.getElementById("complete").addEventListener("click", withdraw);