let key0 = document.getElementById("0");
let key1 = document.getElementById("i");
let key2 = document.getElementById("ii");
let key3 = document.getElementById("iii");
let key4 = document.getElementById("iv");
let key5 = document.getElementById("v");
let key6 = document.getElementById("vi");
let key7 = document.getElementById("vii");
let key8 = document.getElementById("viii");
let key9 = document.getElementById("ix");
let keyC = document.getElementById("c");
let keyBksp = document.getElementById("bksp");

function add0() {
    document.getElementById("wd").value += "0";
}

function add1() {
    document.getElementById("wd").value += "1";
}

function add2() {
    document.getElementById("wd").value += "2";
}

function add3() {
    document.getElementById("wd").value += "3";
}

function add4() {
    document.getElementById("wd").value += "4";
}

function add5() {
    document.getElementById("wd").value += "5";
}

function add6() {
    document.getElementById("wd").value += "6";
}

function add7() {
    document.getElementById("wd").value += "7";
}

function add8() {
    document.getElementById("wd").value += "8";
}

function add9() {
    document.getElementById("wd").value += "9";
}

function cls() {
    if (document.getElementById("wd").value === "") {
        alert("Textbox empty.");
    } else {
        document.getElementById("wd").value = "";
    }
}

function bksp() {
    if (document.getElementById("wd").value === "") {
        alert("Textbox empty.");
    } else {
        let len = document.getElementById("wd").value.length - 1;
        let newVal = "";
        for (i = 0; i < len; i++) {
            newVal += document.getElementById("wd").value[i];
        }

        document.getElementById("wd").value = newVal;
    }
}

key0.addEventListener("click", add0);
key1.addEventListener("click", add1);
key2.addEventListener("click", add2);
key3.addEventListener("click", add3);
key4.addEventListener("click", add4);
key5.addEventListener("click", add5);
key6.addEventListener("click", add6);
key7.addEventListener("click", add7);
key8.addEventListener("click", add8);
key9.addEventListener("click", add9);
keyC.addEventListener("click", cls);
keyBksp.addEventListener("click", bksp);