function red(){
    document.getElementById("red").style.border = "5px solid black";
    document.getElementById("orange").style.border = "5px solid transparent";
    document.getElementById("yellow").style.border = "5px solid transparent";
    document.getElementById("green").style.border = "5px solid transparent";
    document.getElementById("turquoise").style.border = "5px solid transparent";
    document.getElementById("blue").style.border = "5px solid transparent";
    document.getElementById("purple").style.border = "5px solid transparent";
    
    document.getElementById("calculator").style.backgroundColor = "red";
}

function orange(){
    document.getElementById("red").style.border = "5px solid transparent";
    document.getElementById("orange").style.border = "5px solid black";
    document.getElementById("yellow").style.border = "5px solid transparent";
    document.getElementById("green").style.border = "5px solid transparent";
    document.getElementById("turquoise").style.border = "5px solid transparent";
    document.getElementById("blue").style.border = "5px solid transparent";
    document.getElementById("purple").style.border = "5px solid transparent";
    
    document.getElementById("calculator").style.backgroundColor = "orange";
}

function yellow(){
    document.getElementById("red").style.border = "5px solid transparent";
    document.getElementById("orange").style.border = "5px solid transparent";
    document.getElementById("yellow").style.border = "5px solid black";
    document.getElementById("green").style.border = "5px solid transparent";
    document.getElementById("turquoise").style.border = "5px solid transparent";
    document.getElementById("blue").style.border = "5px solid transparent";
    document.getElementById("purple").style.border = "5px solid transparent";
    
    document.getElementById("calculator").style.backgroundColor = "yellow";
}

function green(){
    document.getElementById("red").style.border = "5px solid transparent";
    document.getElementById("orange").style.border = "5px solid transparent";
    document.getElementById("yellow").style.border = "5px solid transparent";
    document.getElementById("green").style.border = "5px solid black";
    document.getElementById("turquoise").style.border = "5px solid transparent";
    document.getElementById("blue").style.border = "5px solid transparent";
    document.getElementById("purple").style.border = "5px solid transparent";
    
    document.getElementById("calculator").style.backgroundColor = "green";
}

function turquoise(){
    document.getElementById("red").style.border = "5px solid transparent";
    document.getElementById("orange").style.border = "5px solid transparent";
    document.getElementById("yellow").style.border = "5px solid transparent";
    document.getElementById("green").style.border = "5px solid transparent";
    document.getElementById("turquoise").style.border = "5px solid black";
    document.getElementById("blue").style.border = "5px solid transparent";
    document.getElementById("purple").style.border = "5px solid transparent";
    
    document.getElementById("calculator").style.backgroundColor = "turquoise";
}

function blue(){
    document.getElementById("red").style.border = "5px solid transparent";
    document.getElementById("orange").style.border = "5px solid transparent";
    document.getElementById("yellow").style.border = "5px solid transparent";
    document.getElementById("green").style.border = "5px solid transparent";
    document.getElementById("turquoise").style.border = "5px solid transparent";
    document.getElementById("blue").style.border = "5px solid black";
    document.getElementById("purple").style.border = "5px solid transparent";
    
    document.getElementById("calculator").style.backgroundColor = "blue";
}

function purple(){
    document.getElementById("red").style.border = "5px solid transparent";
    document.getElementById("orange").style.border = "5px solid transparent";
    document.getElementById("yellow").style.border = "5px solid transparent";
    document.getElementById("green").style.border = "5px solid transparent";
    document.getElementById("turquoise").style.border = "5px solid transparent";
    document.getElementById("blue").style.border = "5px solid transparent";
    document.getElementById("purple").style.border = "5px solid black";
    
    document.getElementById("calculator").style.backgroundColor = "purple";
}

function n0(){
    document.getElementById("neg").disabled = true;
    
    if (document.getElementById("op").value === "" && document.getElementById("n2").value === ""){
        var detected = false;
        var num = document.getElementById("n1").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 0;
            document.getElementById("n1").value += 0;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 0;
            document.getElementById("n1").value += 0;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }
        

    }
    
else if (document.getElementById("n1").value != "" && document.getElementById("op").value != ""){
        var detected = false;
        var num = document.getElementById("n2").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 0;
            document.getElementById("n2").value += 0;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 0;
            document.getElementById("n2").value += 0;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }

    }
}

function n1(){
    document.getElementById("neg").disabled = true;
    
    if (document.getElementById("op").value === "" && document.getElementById("n2").value === ""){
        var detected = false;
        var num = document.getElementById("n1").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 1;
            document.getElementById("n1").value += 1;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 1;
            document.getElementById("n1").value += 1;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }

    }
    
else if (document.getElementById("n1").value != "" && document.getElementById("op").value != ""){
        var detected = false;
        var num = document.getElementById("n2").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 1;
            document.getElementById("n2").value += 1;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 1;
            document.getElementById("n2").value += 1;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }

    }
}

function n2(){
    document.getElementById("neg").disabled = true;
    
    if (document.getElementById("op").value === "" && document.getElementById("n2").value === ""){
        var detected = false;
        var num = document.getElementById("n1").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 2;
            document.getElementById("n1").value += 2;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 2;
            document.getElementById("n1").value += 2;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }

    }
    
else if (document.getElementById("n1").value != "" && document.getElementById("op").value != ""){
        var detected = false;
        var num = document.getElementById("n2").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 2;
            document.getElementById("n2").value += 2;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 2;
            document.getElementById("n2").value += 2;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }

    }
}

function n3(){
    document.getElementById("neg").disabled = true;
    
    if (document.getElementById("op").value === "" && document.getElementById("n2").value === ""){
        var detected = false;
        var num = document.getElementById("n1").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 3;
            document.getElementById("n1").value += 3;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 3;
            document.getElementById("n1").value += 3;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }

    }
    
else if (document.getElementById("n1").value != "" && document.getElementById("op").value != ""){
        var detected = false;
        var num = document.getElementById("n2").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 3;
            document.getElementById("n2").value += 3;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 3;
            document.getElementById("n2").value += 3;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }

    }
}

function n4(){
    document.getElementById("neg").disabled = true;
    
    if (document.getElementById("op").value === "" && document.getElementById("n2").value === ""){
        var detected = false;
        var num = document.getElementById("n1").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 4;
            document.getElementById("n1").value += 4;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 4;
            document.getElementById("n1").value += 4;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }

    }
    
else if (document.getElementById("n1").value != "" && document.getElementById("op").value != ""){
        var detected = false;
        var num = document.getElementById("n2").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 4;
            document.getElementById("n2").value += 4;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 4;
            document.getElementById("n2").value += 4;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }

    }
}

function n5(){
    document.getElementById("neg").disabled = true;
    
    if (document.getElementById("op").value === "" && document.getElementById("n2").value === ""){
        var detected = false;
        var num = document.getElementById("n1").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 5;
            document.getElementById("n1").value += 5;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 5;
            document.getElementById("n1").value += 5;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }

    }
    
else if (document.getElementById("n1").value != "" && document.getElementById("op").value != ""){
        var detected = false;
        var num = document.getElementById("n2").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 5;
            document.getElementById("n2").value += 5;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 5;
            document.getElementById("n2").value += 5;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }

    }
}

function n6(){
    document.getElementById("neg").disabled = true;
    
    if (document.getElementById("op").value === "" && document.getElementById("n2").value === ""){
        var detected = false;
        var num = document.getElementById("n1").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 6;
            document.getElementById("n1").value += 6;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 6;
            document.getElementById("n1").value += 6;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }

    }
    
else if (document.getElementById("n1").value != "" && document.getElementById("op").value != ""){
        var detected = false;
        var num = document.getElementById("n2").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 6;
            document.getElementById("n2").value += 6;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 6;
            document.getElementById("n2").value += 6;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }

    }
}

function n7(){
    document.getElementById("neg").disabled = true;
    
    if (document.getElementById("op").value === "" && document.getElementById("n2").value === ""){
        var detected = false;
        var num = document.getElementById("n1").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 7;
            document.getElementById("n1").value += 7;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 7;
            document.getElementById("n1").value += 7;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }
       
    }
    
else if (document.getElementById("n1").value != "" && document.getElementById("op").value != ""){
        var detected = false;
        var num = document.getElementById("n2").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 7;
            document.getElementById("n2").value += 7;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 7;
            document.getElementById("n2").value += 7;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }

    }
}

function n8(){
    document.getElementById("neg").disabled = true;
    
    if (document.getElementById("op").value === "" && document.getElementById("n2").value === ""){
        var detected = false;
        var num = document.getElementById("n1").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 8;
            document.getElementById("n1").value += 8;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 8;
            document.getElementById("n1").value += 8;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }
      
    }
    
else if (document.getElementById("n1").value != "" && document.getElementById("op").value != ""){
        var detected = false;
        var num = document.getElementById("n2").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 8;
            document.getElementById("n2").value += 8;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 8;
            document.getElementById("n2").value += 8;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }
   
    }
}

function n9(){
    document.getElementById("neg").disabled = true;
    
    if (document.getElementById("op").value === "" && document.getElementById("n2").value === ""){
        var detected = false;
        var num = document.getElementById("n1").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 9;
            document.getElementById("n1").value += 9;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 9;
            document.getElementById("n1").value += 9;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }
    }
    
else if (document.getElementById("n1").value != "" && document.getElementById("op").value != ""){
    
        var detected = false;
        var num = document.getElementById("n2").value;
        for(var i = 0; i <= num.length - 1; i++){
            if (num[i] === "."){
                detected = true;
            }
        }
    
        if (detected === false){
            document.getElementById("equation").value += 9;
            document.getElementById("n2").value += 9;
            
            document.getElementById("dec").disabled = false;
            }
    
        else{
            document.getElementById("equation").value += 9;
            document.getElementById("n2").value += 9;
            
            document.getElementById("add").disabled = false;
            document.getElementById("sub").disabled = false;
            document.getElementById("mul").disabled = false;
            document.getElementById("div").disabled = false;
        }
    }
}

function add(){
    if (document.getElementById("n1").value != "" && document.getElementById("op").value === "" && document.getElementById("n2").value === ""){
        var num = document.getElementById("n1").value;
        if (num.length === 1 && num[0] === "-"){
            alert("You cannot enter an operation while no numerical value has been inputted. Please input a numerical value to continue.");
        }
        
        else{
            document.getElementById("equation").value += " + ";
            document.getElementById("op").value = "+";
        
            document.getElementById("dec").disabled = true;
            document.getElementById("neg").disabled = false;
        }
        
        }
    
    else{
    if(document.getElementById("n1").value === ""){
            alert("Please input a number in order to input an operation.");
            }
    
    else if(document.getElementById("op").value != ""){
            alert("You have already inputted an operation.");
            }
    
    else if(document.getElementById("n2").value != ""){
            alert("You have already inputted an operation.");
            }
        }
}

function sub(){
        if (document.getElementById("n1").value != "" && document.getElementById("op").value === "" && document.getElementById("n2").value === ""){
        var num = document.getElementById("n1").value;
        if (num.length === 1 && num[0] === "-"){
            alert("You cannot enter an operation while no numerical value has been inputted. Please input a numerical value to continue.");
        }
        
        else{
            document.getElementById("equation").value += " - ";
            document.getElementById("op").value = "-";
        
            document.getElementById("dec").disabled = true;
            document.getElementById("neg").disabled = false;
        }
        }
    
    else{
    if(document.getElementById("n1").value === ""){
            alert("Please input a number in order to input an operation.");
            }
    
    else if(document.getElementById("op").value != ""){
            alert("You have already inputted an operation.");
            }
    
    else if(document.getElementById("n2").value != ""){
            alert("You have already inputted an operation.");
            }
        }
}

function mul(){
    if (document.getElementById("n1").value != "" && document.getElementById("op").value === "" && document.getElementById("n2").value === ""){
        var num = document.getElementById("n1").value;
        if (num.length === 1 && num[0] === "-"){
            alert("You cannot enter an operation while no numerical value has been inputted. Please input a numerical value to continue.");
        }
        
        else{
            document.getElementById("equation").value += " × ";
            document.getElementById("op").value = "×";
        
            document.getElementById("dec").disabled = true;
            document.getElementById("neg").disabled = false;
        }
        }
    
    else{
    if(document.getElementById("n1").value === ""){
            alert("Please input a number in order to input an operation.");
            }
    
    else if(document.getElementById("op").value != ""){
            alert("You have already inputted an operation.");
            }
    
    else if(document.getElementById("n2").value != ""){
            alert("You have already inputted an operation.");
            }
        }
}

function div(){
        if (document.getElementById("n1").value != "" && document.getElementById("op").value === "" && document.getElementById("n2").value === ""){
        var num = document.getElementById("n1").value;
        if (num.length === 1 && num[0] === "-"){
            alert("You cannot enter an operation while no numerical value has been inputted. Please input a numerical value to continue.");
        }
        
        else{
            document.getElementById("equation").value += " ÷ ";
            document.getElementById("op").value = "÷";
        
            document.getElementById("dec").disabled = true;
            document.getElementById("neg").disabled = false;
        }
        }
    
        else{
        if(document.getElementById("n1").value === ""){
            alert("Please input a number in order to input an operation.");
            }
    
    else if(document.getElementById("op").value != ""){
            alert("You have already inputted an operation.");
            }
    
    else if(document.getElementById("n2").value != ""){
            alert("You have already inputted an operation.");
            }
        }
}

function equ(){ 
    if (document.getElementById("n1").value == "" || document.getElementById("op").value == "" || document.getElementById("n2").value == ""){
        alert("You are required to enter a full equation before clicking this button.");
        }
    
    else if (document.getElementById("op").value === "+"){
        var ans = parseFloat(document.getElementById("n1").value) + parseFloat(document.getElementById("n2").value);
        document.getElementById("equation").value += " = " + ans;
        
        document.getElementById("0").disabled = true;
        document.getElementById("1").disabled = true;
        document.getElementById("2").disabled = true;
        document.getElementById("3").disabled = true;
        document.getElementById("4").disabled = true;
        document.getElementById("5").disabled = true;
        document.getElementById("6").disabled = true;
        document.getElementById("7").disabled = true;
        document.getElementById("8").disabled = true;
        document.getElementById("9").disabled = true;
        
        document.getElementById("add").disabled = true;
        document.getElementById("sub").disabled = true;
        document.getElementById("mul").disabled = true;
        document.getElementById("div").disabled = true;
             
        document.getElementById("dec").disabled = true;
        document.getElementById("neg").disabled = true;

        document.getElementById("equ").disabled = true;
        
        var count = document.getElementById("count").value;

        document.getElementById("logged").value += count + ". " + document.getElementById("equation").value + "\n\n";
        document.getElementById("count").value = parseFloat(document.getElementById("count").value) + 1;
        }
    
    else if (document.getElementById("op").value === "-"){
             var ans = parseFloat(document.getElementById("n1").value) - parseFloat(document.getElementById("n2").value);
             document.getElementById("equation").value += " = " + ans;
                
             document.getElementById("0").disabled = true;
             document.getElementById("1").disabled = true;
             document.getElementById("2").disabled = true;
             document.getElementById("3").disabled = true;
             document.getElementById("4").disabled = true;
             document.getElementById("5").disabled = true;
             document.getElementById("6").disabled = true;
             document.getElementById("7").disabled = true;
             document.getElementById("8").disabled = true;
             document.getElementById("9").disabled = true;

             document.getElementById("add").disabled = true;
             document.getElementById("sub").disabled = true;
             document.getElementById("mul").disabled = true;
             document.getElementById("div").disabled = true;
        
             document.getElementById("dec").disabled = true;
             document.getElementById("neg").disabled = true;

             document.getElementById("equ").disabled = true;
             
             var count = document.getElementById("count").value;
        
             document.getElementById("logged").value += count + ". " + document.getElementById("equation").value + "\n\n";
             document.getElementById("count").value = parseFloat(document.getElementById("count").value) + 1;
             }
    
    else if (document.getElementById("op").value === "×"){
             var ans = parseFloat(document.getElementById("n1").value) * parseFloat(document.getElementById("n2").value);
             document.getElementById("equation").value += " = " + ans;
        
             document.getElementById("0").disabled = true;
             document.getElementById("1").disabled = true;
             document.getElementById("2").disabled = true;
             document.getElementById("3").disabled = true;
             document.getElementById("4").disabled = true;
             document.getElementById("5").disabled = true;
             document.getElementById("6").disabled = true;
             document.getElementById("7").disabled = true;
             document.getElementById("8").disabled = true;
             document.getElementById("9").disabled = true;

             document.getElementById("add").disabled = true;
             document.getElementById("sub").disabled = true;
             document.getElementById("mul").disabled = true;
             document.getElementById("div").disabled = true;
            
             document.getElementById("dec").disabled = true;
             document.getElementById("neg").disabled = true;

             document.getElementById("equ").disabled = true;
        
             var count = document.getElementById("count").value;
        
             document.getElementById("logged").value += count + ". " + document.getElementById("equation").value + "\n\n";
             document.getElementById("count").value = parseFloat(document.getElementById("count").value) + 1;
            }
    
    else if (document.getElementById("op").value === "÷"){
             var ans = parseFloat(document.getElementById("n1").value) / parseFloat(document.getElementById("n2").value);
             document.getElementById("equation").value += " = " + ans;
        
             document.getElementById("0").disabled = true;
             document.getElementById("1").disabled = true;
             document.getElementById("2").disabled = true;
             document.getElementById("3").disabled = true;
             document.getElementById("4").disabled = true;
             document.getElementById("5").disabled = true;
             document.getElementById("6").disabled = true;
             document.getElementById("7").disabled = true;
             document.getElementById("8").disabled = true;
             document.getElementById("9").disabled = true;

             document.getElementById("add").disabled = true;
             document.getElementById("sub").disabled = true;
             document.getElementById("mul").disabled = true;
             document.getElementById("div").disabled = true;
        
             document.getElementById("dec").disabled = true;
             document.getElementById("neg").disabled = true;

             document.getElementById("equ").disabled = true;
             
             var count = document.getElementById("count").value;
        
             document.getElementById("logged").value += count + ". " + document.getElementById("equation").value + "\n\n";
             document.getElementById("count").value = parseFloat(document.getElementById("count").value) + 1;
             }
}

function cls(){
    document.getElementById("equation").value = "";
    document.getElementById("n1").value = "";
    document.getElementById("op").value = "";
    document.getElementById("n2").value = "";
    
    document.getElementById("0").disabled = false;
    document.getElementById("1").disabled = false;
    document.getElementById("2").disabled = false;
    document.getElementById("3").disabled = false;
    document.getElementById("4").disabled = false;
    document.getElementById("5").disabled = false;
    document.getElementById("6").disabled = false;
    document.getElementById("7").disabled = false;
    document.getElementById("8").disabled = false;
    document.getElementById("9").disabled = false;

    document.getElementById("add").disabled = false;
    document.getElementById("sub").disabled = false;
    document.getElementById("mul").disabled = false;
    document.getElementById("div").disabled = false;

    document.getElementById("equ").disabled = false;
    
    document.getElementById("dec").disabled = true;
    document.getElementById("neg").disabled = false;
}

function dec(){
    if (document.getElementById("op").value === ""){
        document.getElementById("equation").value += ".";
        document.getElementById("n1").value += ".";
        document.getElementById("dec").disabled = true;
        
        document.getElementById("add").disabled = true;
        document.getElementById("sub").disabled = true;
        document.getElementById("mul").disabled = true;
        document.getElementById("div").disabled = true;
    }
    
    else{
        document.getElementById("equation").value += ".";
        document.getElementById("n2").value += ".";
        document.getElementById("dec").disabled = true;
                
        document.getElementById("add").disabled = true;
        document.getElementById("sub").disabled = true;
        document.getElementById("mul").disabled = true;
        document.getElementById("div").disabled = true;
    }
}

function neg(){
    if (document.getElementById("op").value === ""){
        document.getElementById("equation").value += "-";
        document.getElementById("n1").value += "-";
        document.getElementById("neg").disabled = true;
    }
    
    else if(document.getElementById("op").value != ""){
        document.getElementById("equation").value += "-";
        document.getElementById("n2").value += "-";
        document.getElementById("neg").disabled = true;
    }
}

function show(){
    document.getElementById("show").style.visibility = "hidden";
    document.getElementById("hide").style.visibility = "visible";
    document.getElementById("logged").style.visibility = "visible";
    document.getElementById("clear_log").style.visibility = "visible";
}

function hide(){
    document.getElementById("show").style.visibility = "visible";
    document.getElementById("hide").style.visibility = "hidden";
    document.getElementById("logged").style.visibility = "hidden";
    document.getElementById("clear_log").style.visibility = "hidden";
}

function clear_log(){
    if(document.getElementById("logged").value === ""){
       alert("You have no calculation history.");
       }
    
    else{
    document.getElementById("logged").value = "";
    document.getElementById("count").value = 1;
    }
}