#!/bin/bash
clear
echo "***********************************"
echo "Linux Shell Website Diagnostic Tool"
echo "***********************************"
echo "**********************"
echo "Written By: Elijah H. Mullin"
echo "**********************"
echo ""

touch diagnostic.html
echo "<!doctype html>" > diagnostic.html
echo "<html lang='en'>" >> diagnostic.html
echo "<head>" >> diagnostic.html
echo "<meta charset='utf-8' name='viewport' content='initital-scale=1.0' />" >> diagnostic.html
echo "<title>Website Diagnostic</title>" >> diagnostic.html
echo "<style>" >> diagnostic.html
echo "body {" >> diagnostic.html
echo "background-color: black;" >> diagnostic.html
echo "color: limegreen;" >> diagnostic.html
echo "font-family: Courier, sans-serif;" >> diagnostic.html
echo "}" >> diagnostic.html
echo "p {" >> diagnostic.html
echo "background-color: limegreen;" >> diagnostic.html
echo "color: white;" >> diagnostic.html
echo "}" >> diagnostic.html
echo "footer {" >> diagnostic.html
echo "border-top: 1px solid black;" >> diagnostic.html
echo "font-size: 0.8em;" >> diagnostic.html
echo "}" >> diagnostic.html
echo "</style>" >> diagnostic.html
echo "</head>" >> diagnostic.html
echo "<body>" >> diagnostic.html
echo "<h1>Website Diagnostic Results (Linux Version)</h1>" >> diagnostic.html

read -p "Enter the number of websites you want to run a diagnostic on: " NUM

if [ $NUM -gt 0 ]
then
    I=1
    while [ $I -le $NUM ]
    do
        echo ""
        echo "Website #$I:"
        echo ""

        read -p "Enter target domain (example, www.facebook.com): " DOM
        echo "Please standby..."

        echo "<h2>Results for $DOM:</h2>" >> diagnostic.html
        echo "<h3>nslookup $DOM:</h3>" >> diagnostic.html
        echo "<p>" >> diagnostic.html
        nslookup $DOM >> diagnostic.html
        echo "</p>" >> diagnostic.html
        echo "<h3>ping $DOM -c 5:</h3>" >> diagnostic.html
        echo "<p>" >> diagnostic.html
        ping $DOM -c 5 >> diagnostic.html
        echo "</p>" >> diagnostic.html
        echo "<h3>traceroute $DOM:</h3>" >> diagnostic.html
        echo "<p>" >> diagnostic.html
        traceroute $DOM >> diagnostic.html
        echo "</p>" >> diagnostic.html
        echo "<h3>Open $DOM in New Tab:</h3><a href='https://$DOM' target='_blank'>Click Here!</a><br /><br />" >> diagnostic.html

        I=$(($I+1))
    done
else
    ./webInfo.sh
fi

echo "<footer><center><span>&copy; Elijah H. Mullin, 2022</span></center></footer>" >> diagnostic.html
echo "</body>" >> diagnostic.html
echo "</html>" >> diagnostic.html
echo ""

cat diagnostic.html
echo ""
echo "Diagnostic web page created; ready for viewing."